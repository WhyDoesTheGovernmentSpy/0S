python -m pip install matplotlib
python -m pip install scipy
python -m pip install requests
