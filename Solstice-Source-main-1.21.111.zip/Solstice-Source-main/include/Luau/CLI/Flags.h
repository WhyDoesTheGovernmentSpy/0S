// This file is part of the Luau programming language and is licensed under MIT License; see LICENSE.txt for details
#pragma once

void setLuauFlagsDefault();
void setLuauFlags(const char* list);
