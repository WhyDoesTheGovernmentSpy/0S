﻿#pragma once

namespace impl
{
	void showExampleWindow(const char* comment);
}